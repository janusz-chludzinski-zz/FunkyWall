MC,

jeśli byłem dla Ciebie niemiły, a pewnie byłem, to przepraszam. Wiesz dobrze, że JC <3 MC, nawet, jak się czasem nie dogadują.

Ja się przyznaję do błędu, jednak chciałbym, żebyś wiedziała, że czułem się wczoraj jak worek do bicia. Ja rozumiem, że martwisz się tym okresem, ale to nie powód, żeby odbijać to na mnie. Poza tym nie ma powodu do dużych zmartwień, dopóki nie wiadomo co się dokładnie dzieje.

Wróćmy proszę dzisiaj do domu, jakby wczoraj się nic nie wydarzyło. Oferuję przytulanie i smyranie :)
