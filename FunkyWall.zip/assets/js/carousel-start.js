$(document).ready(function(){
  $(".owl-carousel").owlCarousel({
    margin:0,
    loop:true,
    items:1,
    nav: true,
    navText: ['<i class="fas fa-chevron-circle-left nav-item"></i>', '<i class="fas fa-chevron-circle-right nav-item"></i>']
  });
});
